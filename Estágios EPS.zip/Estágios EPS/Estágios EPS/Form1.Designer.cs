﻿namespace Estágios_EPS
{
    partial class Form_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Login));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textbox_password = new System.Windows.Forms.TextBox();
            this.textbox_email = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.menutrip_login = new System.Windows.Forms.MenuStrip();
            this.definicõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.criarContaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iniciarSessãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verificarConexãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fecharprogramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_fechar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.menutrip_login.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_login);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textbox_password);
            this.groupBox1.Controls.Add(this.textbox_email);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(69, 185);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(513, 239);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Iniciar sesão";
            // 
            // btn_login
            // 
            this.btn_login.FlatAppearance.BorderSize = 0;
            this.btn_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_login.Location = new System.Drawing.Point(102, 190);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(169, 27);
            this.btn_login.TabIndex = 4;
            this.btn_login.Text = "Iniciar sessão";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "E-mail:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 137);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Password:";
            // 
            // textbox_password
            // 
            this.textbox_password.Location = new System.Drawing.Point(102, 134);
            this.textbox_password.Name = "textbox_password";
            this.textbox_password.PasswordChar = '#';
            this.textbox_password.Size = new System.Drawing.Size(395, 26);
            this.textbox_password.TabIndex = 1;
            this.textbox_password.Text = "123456789";
            // 
            // textbox_email
            // 
            this.textbox_email.Location = new System.Drawing.Point(102, 75);
            this.textbox_email.Name = "textbox_email";
            this.textbox_email.Size = new System.Drawing.Size(395, 26);
            this.textbox_email.TabIndex = 0;
            this.textbox_email.Text = "123456789";
            this.textbox_email.MouseHover += new System.EventHandler(this.textbox_email_MouseHover);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(188, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(281, 33);
            this.label3.TabIndex = 3;
            this.label3.Text = "Gestão dos estágios";
            // 
            // menutrip_login
            // 
            this.menutrip_login.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menutrip_login.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.definicõesToolStripMenuItem});
            this.menutrip_login.Location = new System.Drawing.Point(0, 0);
            this.menutrip_login.Name = "menutrip_login";
            this.menutrip_login.Size = new System.Drawing.Size(665, 24);
            this.menutrip_login.TabIndex = 4;
            this.menutrip_login.Text = "menuStrip1";
            // 
            // definicõesToolStripMenuItem
            // 
            this.definicõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.criarContaToolStripMenuItem,
            this.iniciarSessãoToolStripMenuItem,
            this.verificarConexãoToolStripMenuItem,
            this.fecharprogramaToolStripMenuItem});
            this.definicõesToolStripMenuItem.Name = "definicõesToolStripMenuItem";
            this.definicõesToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.definicõesToolStripMenuItem.Text = "Definicões";
            // 
            // criarContaToolStripMenuItem
            // 
            this.criarContaToolStripMenuItem.Image = global::Estágios_EPS.Properties.Resources.user;
            this.criarContaToolStripMenuItem.Name = "criarContaToolStripMenuItem";
            this.criarContaToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.criarContaToolStripMenuItem.Text = "Criar conta";
            // 
            // iniciarSessãoToolStripMenuItem
            // 
            this.iniciarSessãoToolStripMenuItem.Image = global::Estágios_EPS.Properties.Resources.unlocked;
            this.iniciarSessãoToolStripMenuItem.Name = "iniciarSessãoToolStripMenuItem";
            this.iniciarSessãoToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.iniciarSessãoToolStripMenuItem.Text = "Iniciar sessão";
            // 
            // verificarConexãoToolStripMenuItem
            // 
            this.verificarConexãoToolStripMenuItem.Image = global::Estágios_EPS.Properties.Resources.info;
            this.verificarConexãoToolStripMenuItem.Name = "verificarConexãoToolStripMenuItem";
            this.verificarConexãoToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.verificarConexãoToolStripMenuItem.Text = "Verificar conexão";
            // 
            // fecharprogramaToolStripMenuItem
            // 
            this.fecharprogramaToolStripMenuItem.Image = global::Estágios_EPS.Properties.Resources.cross;
            this.fecharprogramaToolStripMenuItem.Name = "fecharprogramaToolStripMenuItem";
            this.fecharprogramaToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.fecharprogramaToolStripMenuItem.Text = "Fecharprograma";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(194, 455);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(242, 148);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // btn_fechar
            // 
            this.btn_fechar.BackgroundImage = global::Estágios_EPS.Properties.Resources.cross;
            this.btn_fechar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_fechar.FlatAppearance.BorderSize = 0;
            this.btn_fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_fechar.Location = new System.Drawing.Point(631, 39);
            this.btn_fechar.Name = "btn_fechar";
            this.btn_fechar.Size = new System.Drawing.Size(22, 21);
            this.btn_fechar.TabIndex = 0;
            this.btn_fechar.UseVisualStyleBackColor = true;
            this.btn_fechar.Click += new System.EventHandler(this.btn_fechar_Click);
            // 
            // Form_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 690);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_fechar);
            this.Controls.Add(this.menutrip_login);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menutrip_login;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menutrip_login.ResumeLayout(false);
            this.menutrip_login.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_fechar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textbox_password;
        private System.Windows.Forms.TextBox textbox_email;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MenuStrip menutrip_login;
        private System.Windows.Forms.ToolStripMenuItem definicõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem criarContaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iniciarSessãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verificarConexãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fecharprogramaToolStripMenuItem;
    }
}

