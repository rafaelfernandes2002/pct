﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Estágios_EPS
{
    public partial class Estagios : Form
    {
        public MySqlConnection conn;
        public MySqlConnection conn_2;
        public MySqlCommand comand;
        public static string id = "";

        public void Conexao()
        {
            try
            {
                string servidor = "localhost";
                string user = "root";
                string password = "";
                string BD_Name = "info_users";
                conn = new MySqlConnection("Server=" + servidor + ";Database=" + BD_Name + ";Uid=" + user + ";Pwd=" + password + "");
                comand = conn.CreateCommand();
                conn.Open();

                conn.Close();
            }
            catch
            {
                MessageBox.Show("Não conectou");
            }
        }

        public void Conexao_2()
        {
            try
            {
                string servidor = "localhost";
                string user = "root";
                string password = "";
                string BD_Name = "info_users";
                conn_2 = new MySqlConnection("Server=" + servidor + ";Database=" + BD_Name + ";Uid=" + user + ";Pwd=" + password + "");
                comand = conn.CreateCommand();
                conn_2.Open();
                conn_2.Close();
            }
            catch
            {
                MessageBox.Show("Não conectou");
            }
        }

        public static void combo_cursos() { }

        public Estagios(string id_user)
        {
            InitializeComponent();
            panel_turmas.Location = new Point(358, 27);
            Conexao();
            Conexao_2();

            id = Convert.ToString(id_user);
            MessageBox.Show("O id do utilizador lougado é " + id);
        }

        private void Estagios_Load(object sender, EventArgs e)
        {

        }

        private void btn_criar_curso_Click(object sender, EventArgs e)
        {
            conn.Open();
            MySqlCommand comand1 = conn.CreateCommand();
            comand1.CommandType = CommandType.Text;
            comand1.CommandText = "INSERT INTO cursos (Nome_Curso, Abreviacao_Curso) VALUES ('TECNICO DE GESTÃO E PROGRAMACÃO DE SISTEMAS INFORMATICOS 2020-2023', 'TGPSI 20-23')";
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(comand1);
            da.Fill(dt);
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel_turmas.Visible = true;
            combo_cursos_1.Items.Clear();
            try
            {
                conn.Open();
                MySqlCommand con = new MySqlCommand();
                con.Connection = conn;
                con.CommandText = "select Abreviacao_Curso from cursos";
                MySqlDataReader dr = con.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);

                combo_cursos_1.DisplayMember = "Abreviacao_Curso";
                combo_cursos_1.DataSource = dt;
                combo_cursos_1.SelectedIndex = combo_cursos_1.FindStringExact("Selecione o curso:");

                conn.Close();
            }
            catch
            {

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool erro = false;
            if (string.IsNullOrWhiteSpace(textbox_coodernador.Text))
            {
                MessageBox.Show("Por favor digite o nome do coodernador!");
                erro = true;
            }

            if (string.IsNullOrWhiteSpace(textbox_nome.Text))
            {
                MessageBox.Show("Por favor digite o nome da turma!");
                erro = true;
            }
            
            if(combo_cursos_1.Text.Equals("Selecione o curso:"))
            {
                MessageBox.Show("Escolha um curso!");
                erro = true;
            }

            if (numeric_formacao.Value == 0)
            {
                MessageBox.Show("Diga o ano de formacao!");
                erro = true;
            }

            if (numeric_letivo.Value == 0)
            {
                MessageBox.Show("Diga o ano letivo!");
                erro = true;
            }

            string Abreviacao = combo_cursos_1.Text;
            int Id_curso = 0;
            //Busca ID curso
            try
            {
                conn.Open();
                MySqlCommand comand2 = conn.CreateCommand();
                comand2.CommandType = CommandType.Text;
                comand2.CommandText = "SELECT * FROM cursos where Abreviacao_Curso='" + Abreviacao + "' LIMIT 1";
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(comand2);
                da.Fill(dt);

                MySqlDataReader dr;
                dr = comand2.ExecuteReader();
                dr.Read();

                Id_curso = dr.GetInt32(0);
                conn.Close();
            }
            catch
            {
                erro = true;
                MessageBox.Show("Ocorreu um erro ao buscar o ID do curso!");
            }

            if (erro == false)
            {
                try
                {
                    conn.Open();
                    MySqlCommand inserir_turma = conn.CreateCommand();
                    inserir_turma.CommandType = CommandType.Text;
                    inserir_turma.CommandText = "INSERT INTO turmas (ID_Curso, Nome_Turma, Coodernador_Curso, Ano_Formacao, Ano_Letivo, Visivel) VALUES ('"+ Id_curso + "', '" + textbox_nome.Text + "', '" + textbox_coodernador.Text + "', '" + numeric_formacao.Text + "', '" + numeric_letivo.Text + "', 'SIM')";
                    DataTable dt_turmas = new DataTable();
                    MySqlDataAdapter da_turmas = new MySqlDataAdapter(inserir_turma);
                    da_turmas.Fill(dt_turmas);
                    conn.Close();

                    panel_turmas.Visible = false;
                }
                catch
                {
                    MessageBox.Show("Ocorreu um erro ao criar a turma");
                }
            }
        }

        private void btn_ver_turmas_Click(object sender, EventArgs e)
        {
            panel_ver_turmas.Visible = true;
            /*try
            {*/
                conn.Open();
                MySqlCommand comand2 = conn.CreateCommand();
                comand2.CommandType = CommandType.Text;
                comand2.CommandText = "SELECT * FROM turmas";
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(comand2);
                da.Fill(dt);

                MySqlDataReader dr;
                dr = comand2.ExecuteReader();
                while (dr.Read())
                {
                    string Abreviacao = "Erro";
                    conn_2.Open();
                    MySqlCommand comand3 = conn_2.CreateCommand();
                    comand3.CommandType = CommandType.Text;
                    comand3.CommandText = "SELECT Abreviacao_Curso FROM cursos WHERE ID_Curso='" + dr["ID_Curso"].ToString()+ "'";

                    MySqlDataReader dr3;
                    dr3 = comand3.ExecuteReader();
                    dr3.Read();
                    Abreviacao = dr3["Abreviacao_Curso"].ToString();
                    conn_2.Close();

                    datagrid_turmas.Rows.Add(new object[] {dr["ID_Turma"].ToString(), Abreviacao, dr["Nome_Turma"].ToString(), dr["Coodernador_Curso"].ToString(), dr["Ano_Formacao"].ToString(), dr["Ano_Letivo"].ToString() });
                }

                conn.Close();
           /*}
            catch
            {
                MessageBox.Show("Ocorreu um erro ao buscar o ID do curso!");
            }*/
        }
    }
}
