﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using MySql.Data.MySqlClient;

namespace Estágios_EPS
{
    public partial class Form_Login : Form
    {
        public MySqlConnection conn;
        public MySqlCommand comand;
        public static string id = "";
        public void Conexao()
        {
            try
            {
                string servidor = "localhost";
                string user = "root";
                string password = "";
                string BD_Name = "info_users";
                conn = new MySqlConnection("Server="+ servidor + ";Database="+ BD_Name + ";Uid="+ user + ";Pwd="+ password + "");
                comand = conn.CreateCommand();
                conn.Open();

                conn.Close();
            }
            catch
            {
                MessageBox.Show("Não conectou");
            }
        }

        public Form_Login()
        {
            InitializeComponent();
            Conexao();
            id = "";
            //Para por cores
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#273746");
            btn_login.BackColor = System.Drawing.ColorTranslator.FromHtml("#2E4053");
            btn_login.ForeColor = Color.White;
            menutrip_login.BackColor = System.Drawing.ColorTranslator.FromHtml("#2E4053");
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
        private void btn_login_Click(object sender, EventArgs e)
        {
                int i = 0;
                conn.Open();
                MySqlCommand comand2 = conn.CreateCommand();
                comand2.CommandType = CommandType.Text;
                comand2.CommandText = "SELECT * FROM utilizadores where Identificacao='" + textbox_email.Text + "' and Password='" + textbox_password.Text + "' LIMIT 1";
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(comand2);
                da.Fill(dt);

                i = Convert.ToInt32(dt.Rows.Count.ToString());

                if (i == 0)
                {
                MessageBox.Show("Por favor, verifique se todos os campos estão certos");
                }
                else
                {

                comand2.CommandType = CommandType.Text;

                MySqlDataReader dr;
                dr = comand2.ExecuteReader();
                dr.Read();

                id = dr.GetString(0);

                MessageBox.Show("O login foi efetuado com sucesso");
                this.Hide();
                Estagios abrir_estagios = new Estagios(id);
                abrir_estagios.ShowDialog();
            }
            conn.Close();
        }

        private void textbox_email_MouseHover(object sender, EventArgs e)
        {
            textbox_email.BackColor = System.Drawing.ColorTranslator.FromHtml("#F5F5F5");
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
